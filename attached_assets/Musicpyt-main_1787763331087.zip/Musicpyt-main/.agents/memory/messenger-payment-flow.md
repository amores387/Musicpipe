---
name: Manual Messenger payment flow
description: Why the music download app uses a copy-and-open Messenger handoff with manual PayMaya verification
---

The ordinary Messenger deep link can open the owner's chat but cannot silently send a prefilled customer message or verify a PayMaya reference. Keep the customer request as a copyable message, open the existing chat, and clearly label owner approval as manual unless a future server-side Messenger/payment integration is added.

**Why:** Browser-only automation cannot safely prove payment or send messages through a personal Messenger account, and pretending otherwise would let customers unlock downloads without verified payment.

**How to apply:** If automatic delivery is requested later, use an official Page/Messenger integration and a payment provider webhook with server-side credentials; never expose payment secrets in the browser.