# Giomier's Playlist

Personal music collection page where listeners can preview songs, submit PayMaya payment details, send a download request to Messenger, and unlock Google Drive downloads after the owner manually verifies payment.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/giomier-playlist/src/App.tsx` — playlist, free preview, comments, owner tools, and PayMaya/Messenger download flow
- `artifacts/giomier-playlist/src/index.css` — visual theme, typography, responsive layout, and modal styling
- `artifacts/giomier-playlist/public/` — favicon and static public files

## Architecture decisions

- The first version is a static React/Vite experience and keeps playlist, comments, admin additions, and the browser unlock state in localStorage.
- Downloads remain Google Drive links and are opened only after the local album unlock state is set.
- PayMaya requests are copied to the clipboard and handed off to the existing Messenger contact because a normal Messenger link cannot send a message automatically.
- Payment and unlock-code approval are intentionally manual; the app does not claim that a reference number was verified automatically.

## Product

- Browse and search an 11-track personal collection
- Listen to a free chorus preview
- Submit payment name, mobile number, and PayMaya reference number for a ₱5 album request
- Copy the request and open the owner's Messenger chat
- Enter an owner-provided unlock code after manual payment verification
- Add and remove songs/previews through the owner controls
- Post listener comments and ratings

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
